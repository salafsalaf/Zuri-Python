class Student:
    # [assignment] Skeleton class. Add your code here
    name, age, score, tracks = "", 0, 0.0, [""]
    
    def __init__(self, name="Bola", age=20, tracks=["AB","QS"], score=50.50):
        self.name = name
        self.age = age
        self.tracks = tracks
        self.score = score
        pass

    def change_name(self, newName):
        if(len(newName)):
            self.name = newName
            print("New Name:", self.name)
    
    def change_age(self, newAge):
        if(int(newAge)):
            self.age = int(newAge)
            print("New Age:", str(self.age))

    def add_track(self, tracks):
        self.tracks = tracks
        print("Tracks:", self.tracks)

    def get_score(self):
        print("Score:", str(self.score))
    

Bob = Student(name="Bob", age=26, tracks=["FE","BE"], score=20.90)

# Expected methods
Bob.change_name("Peter")
Bob.change_age(34)
Bob.add_track("UI/UX")
Bob.get_score()
