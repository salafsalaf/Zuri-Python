# Check if two words are anagrams 
# Example:
# find_anagrams("hello", "check") --> False
# find_anagrams("below", "elbow") --> True

def find_anagram(word, anagram):
    # [assignment] Add your code here
    str1 =""

    if(not(len(word)) or not(len(anagram))):
        return False

    for letter in word:
        if(letter==' '):
            continue
        else:
            for letter2 in anagram:
                if(letter == letter2):
                    str1 += letter

    if(len(word) != len(anagram) or str1 != word):
        return False

    return True

arg1 = input("Enter First Word: ")
arg2 = input("Enter Second Word: ")

print(find_anagram(arg1, arg2), "\n")
